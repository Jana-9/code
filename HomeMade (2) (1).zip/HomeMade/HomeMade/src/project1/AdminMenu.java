package project1;

import Project1.Login;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class AdminMenu extends JFrame {

    private JTabbedPane tabbedPane;
    private JPanel addProductPanel;
    private JPanel editProductPanel;
    private JPanel viewOrdersPanel;
    private JPanel panel = new JPanel();
    private Font font = new Font("Arial", Font.PLAIN, 16);

    public AdminMenu() {
        setTitle("Admin Menu ");
        // setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setSize(900, 600);
         setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if (result == JOptionPane.YES_OPTION) {
                    MainScreen.writeDataToFiles();
                    System.exit(0);
                }
            }
        }); 
        
        
        JLabel label = new JLabel("--- Admin Menu ---");
        label.setBounds(350, 11, 300, 50);
        label.setFont(new Font("Ordered",Font.BOLD,25));
        
       //background
       ImageIcon background_image = new ImageIcon("4.jpg");
       Image img = background_image.getImage () ;
       Image temp_img = img.getScaledInstance(1000,800,Image.SCALE_SMOOTH);
       background_image = new ImageIcon(temp_img);
       JLabel background = new JLabel("",background_image,JLabel.CENTER);
       background.setBounds(0, 0, 900, 600);
       
        // Create tabbed pane
        tabbedPane = new JTabbedPane();
        Dimension tabbedPaneSize = new Dimension(750, 450);
        tabbedPane.setPreferredSize(tabbedPaneSize);
        panel.add(tabbedPane);
        panel.setBounds(55, 60, 755, 455);
        panel.setBackground(new Color(0,0,0,0));   
        
        // Create panels for each tab
        addProductPanel = new JPanel();
        editProductPanel = new JPanel();
        viewOrdersPanel = new JPanel();
        createProdunctPanel();
        createEditPanel();
        createViewOrdersPanel();
        tabbedPane.addTab("Add Product", addProductPanel);
        tabbedPane.addTab("Edit Product", editProductPanel);
        tabbedPane.addTab("View Orders", viewOrdersPanel);

        // Add tabbed pane to the frame
        add(label);
        add(panel);
        add(background);
        setVisible(true);
    }

    private void createProdunctPanel() {
        addProductPanel.setLayout(null);
        JLabel itemNameLabel = new JLabel("Item Name:");
        itemNameLabel.setFont(font);
        itemNameLabel.setBounds(140, 30, 200, 30);
        JTextField itemNameField = new JTextField();
        itemNameField.setFont(font);
        itemNameField.setBounds(300, 30, 300, 30);
        JLabel itemTypeLabel = new JLabel("Item Type:");
        itemTypeLabel.setFont(font);
        itemTypeLabel.setBounds(140, 80, 200, 30);
        String[] itemTypes = {"Food", "Resin", "Dessert"};
        JComboBox<String> itemTypeComboBox = new JComboBox<>(itemTypes);
        itemTypeComboBox.setFont(font);
        itemTypeComboBox.setBounds(300, 80, 300, 30);
        JLabel itemPriceLabel = new JLabel("Item Price:");
        itemPriceLabel.setFont(font);
        itemPriceLabel.setBounds(140, 130, 200, 30);
        JTextField itemPriceField = new JTextField();
        itemPriceField.setFont(font);
        itemPriceField.setBounds(300, 130, 300, 30);
        JLabel availableAmountLabel = new JLabel("Available Amount:");
        availableAmountLabel.setFont(font);
        availableAmountLabel.setBounds(140, 180, 200, 30);
        JTextField availableAmountField = new JTextField();
        availableAmountField.setFont(font);
        availableAmountField.setBounds(300, 180, 300, 30);
        JLabel imageIconPathLabel = new JLabel("Item Image Icon Path:");
        imageIconPathLabel.setFont(font);
        imageIconPathLabel.setBounds(140, 230, 200, 30);
        JTextField imageIconPathField = new JTextField();
        imageIconPathField.setFont(font);
        imageIconPathField.setBounds(300, 230, 300, 30);

        addProductPanel.add(itemNameLabel);
        addProductPanel.add(itemNameField);
        addProductPanel.add(itemTypeLabel);
        addProductPanel.add(itemTypeComboBox);
        addProductPanel.add(itemPriceLabel);
        addProductPanel.add(itemPriceField);
        addProductPanel.add(availableAmountLabel);
        addProductPanel.add(availableAmountField);
        addProductPanel.add(imageIconPathLabel);
        addProductPanel.add(imageIconPathField);
        JButton addButton = new JButton("Add");
        addButton.setFont(font);
        addButton.setBounds(130, 300, 200, 30);
         addButton.setForeground(Color.DARK_GRAY);
          addButton.setFont(new Font("",Font.BOLD,17));
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (itemNameField.getText().trim().isEmpty() || itemPriceField.getText().trim().isEmpty()
                            || availableAmountField.getText().trim().isEmpty() || imageIconPathField.getText().trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill in all the required fields.", "Adding new Item Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    String name = itemNameField.getText().trim();
                    String itemType = (String) itemTypeComboBox.getSelectedItem();
                    Admin admin = (Admin) MainScreen.currentPerson;
                    double price = Double.parseDouble(itemPriceField.getText().trim());
                    if (price <= 0) {
                        JOptionPane.showMessageDialog(null, "Invalid item price must be greater than 0", "Adding new Item Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    int avaliableAmount = Integer.parseInt(availableAmountField.getText().trim());
                    if (avaliableAmount <= 0) {
                        JOptionPane.showMessageDialog(null, "Invalid item Available Amount must be greater than 0", "Adding new Item Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    String imageIconPath = imageIconPathField.getText().trim();
                    if (itemType.equals("Food")) {
                        MainScreen.allFoods.add(new Food(name, admin, price, avaliableAmount, imageIconPath));
                    } else if (itemType.equals("Dessert")) {
                        MainScreen.allDessert.add(new Dessert(name, admin, price, avaliableAmount, imageIconPath));
                    } else {
                        MainScreen.allResin.add(new Resin(name, admin, price, avaliableAmount, imageIconPath));
                    }
                    JOptionPane.showMessageDialog(null, "Item " + itemType + " " + name + " has been added successfully", "Adding new Item", JOptionPane.INFORMATION_MESSAGE);
                    itemNameField.setText("");
                    itemPriceField.setText("");
                    availableAmountField.setText("");
                    imageIconPathField.setText("");
                    itemTypeComboBox.setSelectedIndex(0);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input Data " + ex.getMessage(), "Adding new Item Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        JButton cancelButton = new JButton("Go Back");
        cancelButton.setFont(font);
        cancelButton.setBounds(400, 300, 200, 30);
         cancelButton.setForeground(Color.DARK_GRAY);
          cancelButton.setFont(new Font("",Font.BOLD,17));
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MainScreen();
                dispose();
            }
        });

        addProductPanel.add(addButton);
        addProductPanel.add(cancelButton);

    }

    private void createEditPanel() {
        editProductPanel.setLayout(null);
        JLabel itemNameLabel = new JLabel("Item Name:");
        itemNameLabel.setFont(font);
        itemNameLabel.setBounds(140, 50, 200, 30);
        ArrayList<Item> adminItems = getAllAdminItems();
        String[] itemNames = new String[adminItems.size()];
        for (int i = 0; i < adminItems.size(); i++) {
            itemNames[i] = adminItems.get(i).getName();
        }
        JComboBox<String> itemNameComboBox = new JComboBox<>(itemNames);
        itemNameComboBox.setFont(font);
        itemNameComboBox.setBounds(300, 50, 300, 30);
        JLabel itemPriceLabel = new JLabel("Item Price:");
        itemPriceLabel.setFont(font);
        itemPriceLabel.setBounds(140, 120, 200, 30);
        JTextField itemPriceField = new JTextField();
        itemPriceField.setFont(font);
        itemPriceField.setBounds(300, 120, 300, 30);
        JLabel availableAmountLabel = new JLabel("Available Amount:");
        availableAmountLabel.setFont(font);
        availableAmountLabel.setBounds(140, 170, 200, 30);
        JTextField availableAmountField = new JTextField();
        availableAmountField.setFont(font);
        availableAmountField.setBounds(300, 170, 300, 30);
        JLabel imageIconPathLabel = new JLabel("Item Image Icon Path:");
        imageIconPathLabel.setFont(font);
        imageIconPathLabel.setBounds(140, 220, 200, 30);
        JTextField imageIconPathField = new JTextField();
        imageIconPathField.setFont(font);
        imageIconPathField.setBounds(300, 220, 300, 30);
        if (adminItems.size() != 0) {
            itemPriceField.setText(adminItems.get(0).getPrice() + "");
            availableAmountField.setText(adminItems.get(0).getAvaliableAmount() + "");
            imageIconPathField.setText(adminItems.get(0).getImageIconPath());
        }
        itemNameComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (adminItems.size() != 0) {
                    itemPriceField.setText(adminItems.get(itemNameComboBox.getSelectedIndex()).getPrice() + "");
                    availableAmountField.setText(adminItems.get(itemNameComboBox.getSelectedIndex()).getAvaliableAmount() + "");
                    imageIconPathField.setText(adminItems.get(itemNameComboBox.getSelectedIndex()).getImageIconPath());
                }
            }
        });
        editProductPanel.add(itemNameLabel);
        editProductPanel.add(itemNameComboBox);
        editProductPanel.add(itemPriceLabel);
        editProductPanel.add(itemPriceField);
        editProductPanel.add(availableAmountLabel);
        editProductPanel.add(availableAmountField);
        editProductPanel.add(imageIconPathLabel);
        editProductPanel.add(imageIconPathField);
        JButton updateButton = new JButton("Update");
        updateButton.setFont(font);
        updateButton.setBounds(130, 300, 200, 30);
        updateButton.setForeground(Color.DARK_GRAY);
        updateButton.setFont(new Font("",Font.BOLD,17));
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (adminItems.size() == 0) {
                        JOptionPane.showMessageDialog(null, "You do not have any items in our system yet", "Updating an Item", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (itemPriceField.getText().trim().isEmpty()
                            || availableAmountField.getText().trim().isEmpty() || imageIconPathField.getText().trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill in all the required fields.", "Updating an Item Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    int index = itemNameComboBox.getSelectedIndex();
                    double price = Double.parseDouble(itemPriceField.getText().trim());
                    if (price <= 0) {
                        JOptionPane.showMessageDialog(null, "Invalid item price must be greater than 0", "Updating an Item Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    int avaliableAmount = Integer.parseInt(availableAmountField.getText().trim());
                    if (avaliableAmount <= 0) {
                        JOptionPane.showMessageDialog(null, "Invalid item Available Amount must be greater than 0", "Updating an Item Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    String imageIconPath = imageIconPathField.getText().trim();
                    adminItems.get(index).setAvaliableAmount(avaliableAmount);
                    adminItems.get(index).setPrice(price);
                    adminItems.get(index).setImageIconPath(imageIconPath);
                    JOptionPane.showMessageDialog(null, "Item " + itemNames[index] + " has been updated successfully", "Updating an Item", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input Data " + ex.getMessage(), "Updating an Item Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        JButton cancelButton = new JButton("Go Back");
        cancelButton.setFont(font);
        cancelButton.setBounds(400, 300, 200, 30);
        cancelButton.setForeground(Color.DARK_GRAY);
        cancelButton.setFont(new Font("",Font.BOLD,17));
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MainScreen();
                dispose();
            }
        });

        editProductPanel.add(updateButton);
        editProductPanel.add(cancelButton);

    }

    private void createViewOrdersPanel() {
        viewOrdersPanel.setLayout(null);
        JTextArea ordersTextArea = new JTextArea();
        ordersTextArea.setEditable(false);
        ordersTextArea.setFont(font);
        ordersTextArea.setText(getAdminOrders());
        JScrollPane scrollPane = new JScrollPane(ordersTextArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(85, 10, 560, 300);
        viewOrdersPanel.add(scrollPane);
        JButton cancelButton = new JButton("Go Back");
        cancelButton.setFont(font);
        cancelButton.setBounds(250, 355, 200, 30);
        cancelButton.setForeground(Color.DARK_GRAY);
        cancelButton.setFont(new Font("",Font.BOLD,17));
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MainScreen();
                dispose();
            }
        });
        viewOrdersPanel.add(cancelButton);
    }
    
    private String getAdminOrders(){
        String orderInfo = "";
        String userOrderInfo = "";
        double total = 0;
        double userTotal = 0;
        for(int i = 0 ; i < MainScreen.allOrders.size(); i++){
            ArrayList<OrderItem> items = MainScreen.allOrders.get(i).getItems();
            userOrderInfo = "";
            userTotal = 0;
            for(OrderItem orderItem : items){
                if(orderItem.getItem().getOwner().getId() == ((Admin)MainScreen.currentPerson).getId()){
                    userOrderInfo += orderItem.getItem().getName()+"\t"+orderItem.getAmount()+"\t"+orderItem.getItem().getPrice()*orderItem.getAmount()+"\n";
                    total += orderItem.getItem().getPrice()*orderItem.getAmount();
                    userTotal += orderItem.getItem().getPrice()*orderItem.getAmount();
                }
            }
            if(!userOrderInfo.isEmpty()){
                orderInfo += MainScreen.allOrders.get(i).getUser().getFullName()+" Has ordered\n";
                orderInfo += userOrderInfo;
                orderInfo += "Total price for "+MainScreen.allOrders.get(i).getUser().getFullName()+" "+userTotal+"\n\n";
            }
        }
        if(!orderInfo.isEmpty()){
            orderInfo += "Total order price: "+total+"\n";
        }
        if(orderInfo.isEmpty()){
            orderInfo = "You do not have any orders yet for your Items in our System";
        }
        return orderInfo;
    }

    private ArrayList<Item> getAllAdminItems() {
        ArrayList<Item> adminItems = new ArrayList<>();
        for (Item item : MainScreen.allFoods) {
            if (item.getOwner().getId() == ((Admin) MainScreen.currentPerson).getId()) {
                adminItems.add(item);
            }
        }

        for (Item item : MainScreen.allDessert) {
            if (item.getOwner().getId() == ((Admin) MainScreen.currentPerson).getId()) {
                adminItems.add(item);
            }
        }

        for (Item item : MainScreen.allResin) {
            if (item.getOwner().getId() == ((Admin) MainScreen.currentPerson).getId()) {
                adminItems.add(item);
            }
        }
        return adminItems;
    }
}
