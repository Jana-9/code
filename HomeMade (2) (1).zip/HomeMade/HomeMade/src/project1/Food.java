package project1;

public class Food extends Item {

    public Food(String name, Admin owner, double price, int avaliableAmount, String imageIconPath) {
        super(name, owner, price, avaliableAmount,imageIconPath);
    }

}
